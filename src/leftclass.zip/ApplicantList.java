import java.util.ArrayList;
import java.util.List;

public class ApplicantList {
	private List<Applicant> applicantList;
	
	public ApplicantList() {
		applicantList = new ArrayList<Applicant>();
	}
	
	public void createApplicant() {
		
	}
	
	public void modifyApplicant() {
		
	}
	
	public void deleteApplicant() {
		
	}
	
	public Boolean vaildChk() {
		return true;
	}
	
	public Applicant searchApplicant() {
		return applicantList.get(0);
	}
}
