
public class Application {
	private String academicBg;
	private String licence;
	private String companyName;
	private String introduction;
	private int foreignLangScore;
	private String major;
	
	public Application() {
		
	}

	public Application(String academicBg, String licence, String companyName, String introduction, int foreignLangScore,
			String major) {
		super();
		setAcademicBg(academicBg);
		setLicence(licence);
		setCompanyName(companyName);
		setIntroduction(introduction);
		setForeignLangScore(foreignLangScore);
		setMajor(major);
	}

	public String getAcademicBg() {
		return academicBg;
	}

	public void setAcademicBg(String academicBg) {
		this.academicBg = academicBg;
	}

	public String getLicence() {
		return licence;
	}

	public void setLicence(String licence) {
		this.licence = licence;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getIntroduction() {
		return introduction;
	}

	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

	public int getForeignLangScore() {
		return foreignLangScore;
	}

	public void setForeignLangScore(int foreignLangScore) {
		this.foreignLangScore = foreignLangScore;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}
}
