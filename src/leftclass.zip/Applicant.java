import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Applicant {
	private String name;
	private String gender;
	private Date birth;
	private List<Application> applicationList;
	private String id;
	private String passwd;
	private int phoneNumber;
	
	public Applicant(String name, String gender, Date birth, String id,
			String passwd, int phoneNumber) {
		setName(name);
		setGender(gender);
		setBirth(birth);
		setId(id);
		setPasswd(passwd);
		setPhoneNumber(phoneNumber);
		
		applicationList = new ArrayList<Application>();
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getBirth() {
		return birth;
	}
	public void setBirth(Date birth) {
		this.birth = birth;
	}
	public List<Application> getApplicationList() {
		return applicationList;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public void createApplication(String academicBg, String licence, String companyName, String introduction, int foreignLangScore,
			String major) {
		applicationList.add( new Application(academicBg, licence, companyName, introduction, foreignLangScore, major) );
	}
	
	public void modifyApllication() {
		
	}
	
	public void deleteApllication() {
		
	}
}
